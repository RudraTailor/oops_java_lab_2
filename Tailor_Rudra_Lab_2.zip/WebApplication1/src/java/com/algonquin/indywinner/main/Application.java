package com.algonquin.indywinner.main;

import com.algonquin.indywinner.service.IndyWinnerService;

/**
 * The {@code Application} class serves as the entry point to the IndyWinner application.
 * It demonstrates basic operations such as adding, retrieving, and deleting Indy winners
 * using the {@link IndyWinnerService}.
 * 
 * 
 * The application showcases:
 * 
 *     Adding a new Indy winner
 *     Retrieving and displaying all Indy winners
 *     Deleting an Indy winner by year
 * 
 * @author Rudra
 * @version 1.0
 * @since 2024-11-24
 */
/**
 * serves as the entry point to the application.
 * @author Rudra
 */
public class Application {

    /**
     * The main method serves as the entry point to the application.
     * It performs various operations on Indy winners through the {@link IndyWinnerService}.
     * 
     * @param args command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        // Create a service instance for managing Indy winners
        IndyWinnerService service = new IndyWinnerService();

        // Add a new winner to the database
        boolean isAdded = service.addWinner(2024, "Rudra Tailor", 250.5, "CAN");
        if (isAdded) {
            System.out.println("Winner added successfully!");
        } else {
            System.out.println("Failed to add winner.");
        }

        // Retrieve and display all winners
        service.getAllWinners();

        // Delete a winner by year
        boolean isDeleted = service.deleteWinner(2023);
        if (isDeleted) {
            System.out.println("Winner deleted successfully!");
        } else {
            System.out.println("Failed to delete winner.");
        }

        // Display the updated list of winners
        service.getAllWinners();
    }
}
