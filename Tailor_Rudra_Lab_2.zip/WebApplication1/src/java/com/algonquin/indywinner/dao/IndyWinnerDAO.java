package com.algonquin.indywinner.dao;

import java.util.List;
import java.sql.SQLException;

import com.algonquin.indywinner.model.IndyWinner;

/**
 * The {@code IndyWinnerDAO} interface defines the data access methods for
 * interacting with the Indy Winner database.
 * <p>
 * This interface allows fetching paginated lists of Indy winners and
 * retrieving the total count of winners in the database.
 * </p>
 * 
 * @author Rudra
 */
public interface IndyWinnerDAO {

    /**
     * Retrieves a paginated list of Indy winners.
     *
     * @param page the page number to retrieve (starting from 1).
     * @param pageSize the number of records per page.
     * @return a {@code List} of {@link IndyWinner} objects for the specified page.
     * @throws SQLException if a database access error occurs.
     */
    List<IndyWinner> getWinnersByPage(int page, int pageSize) throws SQLException;

    /**
     * Retrieves the total number of Indy winners in the database.
     *
     * @return the total count of Indy winners.
     * @throws SQLException if a database access error occurs.
     */
    int getTotalWinners() throws SQLException;
}
