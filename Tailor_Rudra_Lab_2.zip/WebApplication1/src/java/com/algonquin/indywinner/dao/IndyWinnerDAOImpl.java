package com.algonquin.indywinner.dao;

import com.algonquin.indywinner.model.IndyWinner;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of the {@link IndyWinnerDAO} interface for accessing and manipulating
 * IndyWinners data in the database. Provides methods for pagination and retrieving
 * the total count of winners.
 * 
 * @author Mingyang Gao
 * @version 1.0.1
 * @since 2024-11-12
 */
public class IndyWinnerDAOImpl implements IndyWinnerDAO {

    /** Database connection instance for executing queries. */
    private final Connection connection;

    /**
     * Constructs an instance of {@code IndyWinnerDAOImpl} with a specified database connection.
     * 
     * @param connection a valid SQL database connection.
     */
    public IndyWinnerDAOImpl(Connection connection) {
        this.connection = connection;
    }

    /**
     * Retrieves a paginated list of IndyWinners from the database.
     *
     * @param page the page number to retrieve (starting from 1).
     * @param pageSize the number of winners per page.
     * @return a {@code List} of {@link IndyWinner} objects for the specified page.
     * @throws SQLException if a database access error occurs.
     */
    @Override
    public List<IndyWinner> getWinnersByPage(int page, int pageSize) throws SQLException {
        List<IndyWinner> winners = new ArrayList<>();
        int offset = (page - 1) * pageSize;

        String sql = "SELECT YEAR, DRIVER, AVERAGESPEED, COUNTRY FROM INDYWINNERS ORDER BY YEAR DESC LIMIT ? OFFSET ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, pageSize);
            statement.setInt(2, offset);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int year = resultSet.getInt("YEAR");
                    String driver = resultSet.getString("DRIVER");
                    double averageSpeed = resultSet.getDouble("AVERAGESPEED");
                    String country = resultSet.getString("COUNTRY");
                    winners.add(new IndyWinner(year, driver, averageSpeed, country));
                }
            }
        }
        return winners;
    }

    /**
     * Retrieves the total number of IndyWinners in the database.
     *
     * @return the total count of winners in the database.
     * @throws SQLException if a database access error occurs.
     */
    @Override
    public int getTotalWinners() throws SQLException {
        String sql = "SELECT COUNT(*) FROM INDYWINNERS";

        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        }
        return 0;
    }

    /**
     * Closes the database connection associated with this DAO implementation.
     *
     * @throws SQLException if an error occurs while closing the connection.
     */
    public void closeConnection() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }
}
