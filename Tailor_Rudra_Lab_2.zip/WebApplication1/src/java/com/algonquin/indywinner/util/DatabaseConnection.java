package com.algonquin.indywinner.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * The {@code DatabaseConnection} utility class provides methods for establishing and managing
 * a connection to the MySQL database used by the application.
 * 
 * It includes methods for obtaining a database connection and safely closing it.
 * 
 * Features:
 * 
 *   Connects to the MySQL database using JDBC.
 *     Handles safe closure of database connections.
 * 
 * 
 * Ensure that the MySQL JDBC Driver is included in the project's dependencies.
 * 
 * 
 * @author Rudra
 * @version 1.0
 * @since 2024-11-24
 */
public class DatabaseConnection {
    public DatabaseConnection(){}
    /** The database URL for the MySQL connection. */
    private static final String DB_URL = "jdbc:mysql://localhost:3306/indywinners";

    /** The username for the database connection.*/
    private static final String USER = "root";

    /** The password for the database connection. */
    private static final String PASSWORD = "root";

    /**
     * Establishes and returns a connection to the MySQL database.
     * 
     * <p>
     * The method uses the {@link DriverManager#getConnection(String, String, String)} method
     * to create and return a valid {@link Connection} object.
     * </p>
     * 
     * @return a valid {@link Connection} object to interact with the database.
     * @throws SQLException if a database access error occurs or the database URL is invalid.
     */
    public static Connection getConnection() throws SQLException {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found. Ensure it is added to your project's dependencies.", e);
        }
        // Return the database connection
        return DriverManager.getConnection(DB_URL, USER, PASSWORD);
    }

    /**
     * Closes the provided database connection safely.
     * 
     * <p>
     * This method checks if the connection is not null before attempting to close it.
     * If an error occurs during closure, it logs the error to the standard error stream.
     * </p>
     * 
     * @param connection the {@link Connection} object to close. Can be {@code null}.
     */
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("Failed to close the database connection: " + e.getMessage());
            }
        }
    }
}
