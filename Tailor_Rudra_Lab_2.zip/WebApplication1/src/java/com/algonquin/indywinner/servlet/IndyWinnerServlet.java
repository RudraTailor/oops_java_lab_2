package com.algonquin.indywinner.servlet;

import com.algonquin.indywinner.dao.IndyWinnerDAO;
import com.algonquin.indywinner.dao.IndyWinnerDAOImpl;
import com.algonquin.indywinner.model.IndyWinner;
import com.algonquin.indywinner.util.DatabaseConnection;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * The {@code IndyWinnerServlet} class is a servlet for managing and displaying
 * paginated lists of Indianapolis 500 winners.
 * <p>
 * It interacts with the {@link IndyWinnerDAO} to retrieve winner data and
 * generate an HTML response with pagination links.
 * </p>
 * 
 * <p>
 * URL Mapping: {@code /IndyWinnerServlet}
 * </p>
 * 
 * <p>
 * Servlet lifecycle methods such as {@code init}, {@code doGet}, and
 * {@code destroy} are overridden to provide specific functionality.
 * </p>
 * 
 * @author Rudra
 * @version 1.0
 * @since 2024-11-24
 */
@WebServlet("/IndyWinnerServlet")
public class IndyWinnerServlet extends HttpServlet {
    public IndyWinnerServlet(){}
    /** DAO for accessing Indy winner data. */
    private IndyWinnerDAO indyWinnerDAO;

    /**
     * Initializes the servlet and sets up the database connection.
     * 
     * @throws ServletException if a database connection error occurs.
     */
    @Override
    public void init() throws ServletException {
        try {
            Connection connection = DatabaseConnection.getConnection();
            indyWinnerDAO = new IndyWinnerDAOImpl(connection);
        } catch (SQLException e) {
            throw new ServletException("Failed to connect to database", e);
        }
    }

    /**
     * Handles HTTP GET requests to fetch and display paginated lists of Indy winners.
     * 
     * @param request the {@link HttpServletRequest} object containing client request data.
     * @param response the {@link HttpServletResponse} object for sending the response back to the client.
     * @throws ServletException if an error occurs while retrieving data.
     * @throws IOException if an I/O error occurs during response generation.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int pageNumber = 1;
        int pageSize = 10;

        // Get the page number from query parameters
        String pageParam = request.getParameter("page");
        if (pageParam != null) {
            try {
                pageNumber = Integer.parseInt(pageParam);
            } catch (NumberFormatException ex) {
                pageNumber = 1; // Default to page 1 on invalid input
            }
        }

        try {
            // Fetch winners for the current page
            List<IndyWinner> winners = indyWinnerDAO.getWinnersByPage(pageNumber, pageSize);

            // Fetch the total number of winners and calculate total pages
            int totalWinners = indyWinnerDAO.getTotalWinners();
            int totalPages = (int) Math.ceil((double) totalWinners / pageSize);

            // Set response content type
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();

            // Generate HTML response
            out.println("<html><head><title>Indy Winners</title></head><body>");
            out.println("<h1>Indianapolis 500 Winners</h1>");

            // Display winners in an HTML table
            out.println("<table border='1'>");
            out.println("<tr><th>Year</th><th>Driver</th><th>Average Speed (mph)</th><th>Country</th></tr>");
            for (IndyWinner winner : winners) {
                out.printf("<tr><td>%d</td><td>%s</td><td>%.2f</td><td>%s</td></tr>",
                        winner.getYear(), winner.getDriver(), winner.getAverageSpeed(), winner.getCountry());
            }
            out.println("</table>");

            // Add pagination links
            out.println("<div style='margin-top:20px;'>");
            if (pageNumber > 1) {
                out.printf("<button><a href='IndyWinnerServlet?page=%d'>Previous</a></button> ", pageNumber - 1);
            }
            for (int i = 1; i <= totalPages; i++) {
                if (i == pageNumber) {
                    out.printf("<strong>%d</strong> ", i);
                } else {
                    out.printf("<a href='IndyWinnerServlet?page=%d'>%d</a> ", i, i);
                }
            }
            if (pageNumber < totalPages) {
                out.printf("<button><a href='IndyWinnerServlet?page=%d'>Next</a></button>", pageNumber + 1);
            }
            out.println("</div>");

            out.println("</body></html>");
        } catch (SQLException ex) {
            throw new ServletException("Error retrieving Indy Winners", ex);
        }
    }

    /**
     * Cleans up resources when the servlet is destroyed.
     * Closes the database connection associated with the DAO.
     */
    @Override
    public void destroy() {
        try {
            if (indyWinnerDAO instanceof IndyWinnerDAOImpl) {
                ((IndyWinnerDAOImpl) indyWinnerDAO).closeConnection();
            }
        } catch (Exception ex) {
            // Log the error (optional)
        }
    }
}
