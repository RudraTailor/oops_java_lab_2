package com.algonquin.indywinner.service;

import com.algonquin.indywinner.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * The {@code IndyWinnerService} class provides methods for managing the
 * INDYWINNERS database table. It supports operations such as adding a new
 * winner, retrieving all winners, and deleting a winner by year.
 * 
 * <p>
 * This class interacts with the database using a {@link DatabaseConnection}.
 * </p>
 * 
 * @author Rudra
 * @version 1.0
 * @since 2024-11-24
 */
public class IndyWinnerService {
    public IndyWinnerService(){}
    /**
     * Adds a new winner record to the INDYWINNERS table.
     * 
     * @param year the year of the race.
     * @param driver the name of the driver.
     * @param averageSpeed the average speed of the driver.
     * @param country the country of the driver.
     * @return {@code true} if the record was added successfully; {@code false} otherwise.
     */
    public boolean addWinner(int year, String driver, double averageSpeed, String country) {
        String insertQuery = "INSERT INTO INDYWINNERS (YEAR, DRIVER, AVERAGESPEED, COUNTRY) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {

            preparedStatement.setInt(1, year);
            preparedStatement.setString(2, driver);
            preparedStatement.setDouble(3, averageSpeed);
            preparedStatement.setString(4, country);
            return preparedStatement.executeUpdate() > 0; // Returns true if insertion succeeds.

        } catch (SQLException e) {
            System.err.println("Error adding winner: " + e.getMessage());
        }
        return false;
    }

    /**
     * Retrieves and displays all records from the INDYWINNERS table.
     * 
     * <p>
     * The method prints the details of all winners in a tabular format to the
     * console.
     * </p>
     */
    public void getAllWinners() {
        String selectQuery = "SELECT * FROM INDYWINNERS";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            System.out.println("INDY Winners List:");
            System.out.printf("%-10s %-20s %-15s %-10s%n", "YEAR", "DRIVER", "AVG SPEED", "COUNTRY");
            while (resultSet.next()) {
                int year = resultSet.getInt("YEAR");
                String driver = resultSet.getString("DRIVER");
                double averageSpeed = resultSet.getDouble("AVERAGESPEED");
                String country = resultSet.getString("COUNTRY");
                System.out.printf("%-10d %-20s %-15.2f %-10s%n", year, driver, averageSpeed, country);
            }

        } catch (SQLException e) {
            System.err.println("Error retrieving winners: " + e.getMessage());
        }
    }

    /**
     * Deletes a winner record based on the year.
     * 
     * @param year the year of the winner to delete.
     * @return {@code true} if the record was deleted successfully; {@code false} otherwise.
     */
    public boolean deleteWinner(int year) {
        String deleteQuery = "DELETE FROM INDYWINNERS WHERE YEAR = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {

            preparedStatement.setInt(1, year);
            return preparedStatement.executeUpdate() > 0; // Returns true if deletion succeeds.

        } catch (SQLException e) {
            System.err.println("Error deleting winner: " + e.getMessage());
        }
        return false;
    }
}
