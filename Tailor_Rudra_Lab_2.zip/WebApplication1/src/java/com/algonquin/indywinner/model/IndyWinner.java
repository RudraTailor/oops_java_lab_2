package com.algonquin.indywinner.model;

/**
 * The {@code IndyWinner} class represents an Indy race winner with details such as
 * the year of the win, the driver's name, the average speed, and the driver's country.
 * 
 * <p>
 * This class serves as a model for storing and retrieving data related to Indy race winners.
 * </p>
 * 
 * @author Rudra
 * @version 1.0
 * @since 2024-11-24
 */
public class IndyWinner {
    /** The year of the race win. */
    private int year;

    /** The name of the driver who won the race. */
    private String driver;

    /** The average speed achieved during the race. */
    private double averageSpeed;

    /** The country of the winning driver. */
    private String country;

    /**
     * Constructs an {@code IndyWinner} object with the specified details.
     * 
     * @param year the year of the race win.
     * @param driver the name of the winning driver.
     * @param averageSpeed the average speed achieved during the race.
     * @param country the country of the winning driver.
     */
    public IndyWinner(int year, String driver, double averageSpeed, String country) {
        this.year = year;
        this.driver = driver;
        this.averageSpeed = averageSpeed;
        this.country = country;
    }

    /**
     * Gets the year of the race win.
     * 
     * @return the year of the race win.
     */
    public int getYear() {
        return year;
    }

    /**
     * Sets the year of the race win.
     * 
     * @param year the year to set.
     */
    public void setYear(int year) {
        this.year = year;
    }

    /**
     * Gets the name of the winning driver.
     * 
     * @return the name of the winning driver.
     */
    public String getDriver() {
        return driver;
    }

    /**
     * Sets the name of the winning driver.
     * 
     * @param driver the driver's name to set.
     */
    public void setDriver(String driver) {
        this.driver = driver;
    }

    /**
     * Gets the average speed achieved during the race.
     * 
     * @return the average speed achieved.
     */
    public double getAverageSpeed() {
        return averageSpeed;
    }

    /**
     * Sets the average speed achieved during the race.
     * 
     * @param averageSpeed the average speed to set.
     */
    public void setAverageSpeed(double averageSpeed) {
        this.averageSpeed = averageSpeed;
    }

    /**
     * Gets the country of the winning driver.
     * 
     * @return the country of the winning driver.
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the country of the winning driver.
     * 
     * @param country the country to set.
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Returns a string representation of the {@code IndyWinner} object.
     * 
     * @return a string containing the details of the Indy winner.
     */
    @Override
    public String toString() {
        return "IndyWinner{" +
                "year=" + year +
                ", driver='" + driver + '\'' +
                ", averageSpeed=" + averageSpeed +
                ", country='" + country + '\'' +
                '}';
    }
}
